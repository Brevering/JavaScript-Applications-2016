# Promises and Asynchronous Programming
## Homework Assignments

### Task 1. GeoLocation
- Write script that gets the users location and renders a image with the map of that location.
  - Use ES2015 `Promise`

### Task 2. Popup then load
- Write script that shows a message in a popup `<div>` and after 2 seconds redirects to a different site.
  - Use `setTimeout` within a `Promise`